/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmlapplication;

import static java.lang.Integer.parseInt;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

/**
 *
 * @author jsoler rec_project
 */
public class FXMLDocumentController implements Initializable {
    private Label labelMessage;
    @FXML
    private VBox boxM2;
    @FXML
    private HBox boxM;
    @FXML
    private Text text1;
    @FXML
    private TextField cadena;
    @FXML
    private ListView<String> tabla;
    @FXML
    private HBox box;
    @FXML
    private HBox blanco;
    @FXML
    private VBox a;
    @FXML
    private Text puntos;
    
    ObservableList <String> tablita;
    @FXML
    private Button Add;
    @FXML
    private Button Delete;
    @FXML
    private Text text2;
    @FXML
    private Text s;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        tablita = FXCollections.observableArrayList();
        tabla.setItems(tablita);
        
        Add.disableProperty().bind((cadena.textProperty().lessThan(" ")));
        
        tabla.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) -> {
            if (tabla.isFocused() || Delete.isFocused()){
                Delete.disableProperty().set(false);
            } else {
                Delete.disableProperty().set(true);
            }
        });
    }    

    @FXML
    private void surrender(ActionEvent event) {
        
        Alert alerta = new Alert(AlertType.CONFIRMATION);
        alerta.setTitle ("Syllabes - Surrender");
        alerta.setHeaderText ("Confirmación");
        alerta.setContentText ("Edwin, are you sure to surrender?");
        alerta.showAndWait();
      
        String e = alerta.getResult().toString();
        
        if (e.contains("Aceptar")){
            puntos.setText("0");
            tablita = FXCollections.observableArrayList();
            tabla.setItems(tablita);
            cadena.setText("");
        }
        
    }

    @FXML
    private void add(ActionEvent event) {
        tablita.add(cadena.getText());
        cadena.setText("");
        tabla.setItems(tablita);
        Integer e = parseInt(puntos.getText());
        e += 25;
        puntos.setText(e.toString());
    }

    @FXML
    private void delete(ActionEvent event) {
        int i = tabla.getSelectionModel().getSelectedIndex();
        tablita.remove(i);
        tabla.refresh();
        
        Integer e = parseInt(puntos.getText());
        e -= 25;
        puntos.setText(e.toString());
        
        Delete.disableProperty().set(true);
    }
    
}
